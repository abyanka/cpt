cpt.analysis <-
function (Z, T, paired = FALSE, perm.N = 1000, leaveout.N = 100, 
    do_LOO = FALSE, do_5fold = TRUE, do_logistic2 = TRUE, do_forest = TRUE) 
{
    rval = list()
    rval[["lda"]] = list()
    rval[["logistic"]] = list()
    rval[["logistic2"]] = list()
    rval[["forest"]] = list()
    for (metric in c("rate", "mse", "probability")) {
        rval[["lda"]][[metric]] = try(cpt(Z, T, paired = paired, 
            leaveout = 0, class.methods = "lda", metric = metric, 
            perm.N = perm.N, leaveout.N = leaveout.N))
        rval[["logistic"]][[metric]] = try(cpt(Z, T, paired = paired, 
            leaveout = 0, class.methods = "logistic", metric = metric, 
            perm.N = perm.N, leaveout.N = leaveout.N))
        if (do_logistic2) 
            rval[["logistic2"]][[metric]] = try(cpt(Z, T, paired = paired, 
                leaveout = 0, class.methods = "logistic2", metric = metric, 
                perm.N = perm.N, leaveout.N = leaveout.N))
        if (do_forest) 
            rval[["forest"]][[metric]] = try(cpt(Z, T, paired = paired, 
                leaveout = 0, class.methods = "forest", metric = metric, 
                perm.N = perm.N, leaveout.N = leaveout.N))
        if (do_LOO) {
            rval[["lda_LOO"]][[metric]] = try(cpt(Z, T, paired = paired, 
                leaveout = 1, class.methods = "lda", metric = metric, 
                perm.N = perm.N, leaveout.N = nrow(Z)))
            rval[["logistic_LOO"]][[metric]] = try(cpt(Z, T, 
                paired = paired, leaveout = 1, class.methods = "logistic", 
                metric = metric, perm.N = perm.N, leaveout.N = nrow(Z)))
            if (do_logistic2) 
                rval[["logistic2_LOO"]][[metric]] = try(cpt(Z, 
                  T, paired = paired, leaveout = 1, class.methods = "logistic2", 
                  metric = metric, perm.N = perm.N, leaveout.N = nrow(Z)))
        }
        if (do_5fold) {
            rval[["lda_5fold"]][[metric]] = try(cpt(Z, T, paired = paired, 
                leaveout = 0.2, class.methods = "lda", metric = metric, 
                perm.N = perm.N, leaveout.N = leaveout.N))
            rval[["logistic_5fold"]][[metric]] = try(cpt(Z, T, 
                paired = paired, leaveout = 0.2, class.methods = "logistic", 
                metric = metric, perm.N = perm.N, leaveout.N = leaveout.N))
            if (do_logistic2) 
                rval[["logistic2_5fold"]][[metric]] = try(cpt(Z, 
                  T, paired = paired, leaveout = 0.2, class.methods = "logistic2", 
                  metric = metric, perm.N = perm.N, leaveout.N = leaveout.N))
        }
    }
    T = as.factor(T)
    if (length(levels(T)) == 2) {
        groupindex = c(which(as.numeric(T) == 1), which(as.numeric(T) == 
            2))
        sizes = c(sum(as.numeric(T) == 1), sum(as.numeric(T) == 
            2))
        rval[["energy"]] = try(eqdist.etest(Z[groupindex, ], 
            sizes = sizes, R = 999))
        rval[["crossmatch"]] = try(crosstest(Z, T))
    }
    return(rval)
}
