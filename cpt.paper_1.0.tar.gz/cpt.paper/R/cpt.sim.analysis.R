cpt.sim.analysis <-
function (Z, T, class.methods = c("logistic", "logistic2", "forest"), 
    perm.N = 500, metric = "rate", ensemble.metric = "vote", 
    comb.methods = c(class.methods, "ensemble")) 
{
    pvals = rep(NA, length(class.methods) + 5)
    names(pvals) = c(class.methods, "ensemble", "combined", "energy", 
        "crossmatch", "hotelling")
    rval = cpt(Z, T, class.methods = class.methods, metric = metric, 
        ensemble.metric = ensemble.metric, perm.N = perm.N, comb.methods = comb.methods)
    pvals[class.methods] = rval$pvals[class.methods]
    pvals["ensemble"] = rval$pvals["ensemble"]
    pvals["combined"] = rval$pval
    groupindex = c(which(as.numeric(T) == 1), which(as.numeric(T) == 
        2))
    sizes = c(sum(as.numeric(T) == 1), sum(as.numeric(T) == 2))
    pvals["energy"] = eqdist.etest(Z[groupindex, ], sizes = sizes, 
        R = 999)$p.value
    pvals["crossmatch"] = crosstest(Z, T)$approxpval
    pvals["hotelling"] = hotelling.test(Z[as.numeric(T) == 1, 
        ], Z[as.numeric(T) == 2, ])$pval
    return(pvals)
}
